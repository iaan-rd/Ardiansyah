const tampilkanIdentitas = () => {
    const nama = "Ardiansyah Mega Pratama";
    const NPM = "25903460012";
    const prodi = "Teknologi Rekayasa Multimedia";
    const semester = 3;

    console.log(`IDENTITAS MAHASISWA`);
    console.log(`Nama          : ${nama}`);
    console.log(`NPM           : ${NPM}`);
    console.log(`Program Studi : ${prodi}`);
    console.log(`Semester      : ${semester}`);
};

tampilkanIdentitas();