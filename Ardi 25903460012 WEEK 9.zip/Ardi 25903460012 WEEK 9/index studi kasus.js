let nama = "Budi Santoso";
let gajiPokok = 5000000;
let tunjangan = 1000000;
let bonus = 500000;

const hitungGaji = () => {
    let totalPendapatan = gajiPokok + tunjangan + bonus;
    let potongan = totalPendapatan * 5 / 100;
    let gajiBersih = totalPendapatan - potongan;

    console.log(`Nama Karyawan: ${nama}`);
    console.log(`Gaji Pokok: Rp${gajiPokok}`);
    console.log(`Tunjangan: Rp${tunjangan}`);
    console.log(`Bonus: Rp${bonus}`);
    console.log(`Total Pendapatan: Rp${totalPendapatan}`);
    console.log(`Potongan 5%: Rp${potongan}`);
    console.log(`Gaji Bersih: Rp${gajiBersih}`);
};

hitungGaji();